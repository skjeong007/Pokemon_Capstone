General Overview of Files:

pokemon.csv : a compilation of all Pokemon that currently have been released. Includes attributes such as Attack, Health, and other statistics.
combats.csv : aggregation of 50,000 individual combat outcomes that were randomized and physically tested. 
Pokemon_Capstone_Jupyter : The finalized Jupyter notebook that contains the code behind my capstone project.
Capstone_Presentation_Edit : Powerpoint deck used for Demo Day presentation purposes. Very basic overview on project.